library entities;

export 'user.dart';
export 'contact.dart';
export 'course.dart';
export 'lesson.dart';
export 'base.dart';
export 'msg.dart';
export 'msgcontent.dart';
export 'message.dart';
export 'chat.dart';
export 'chatcall.dart';

